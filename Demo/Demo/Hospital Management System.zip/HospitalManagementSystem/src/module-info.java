/**
 * 
 */
/**
 * @author Bichoy Emad
 *
 */
module HospitalManagementSystem {
	requires java.sql;
}