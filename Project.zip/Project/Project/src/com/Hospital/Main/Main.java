package com.Hospital.Main;
import com.Hospital.View.Login;
public class Main{
	public static void main(String[] args){
		new Login().login();
	}
}
