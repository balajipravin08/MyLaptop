package com.Hospital.Model;

public interface Operations {
	void operation(User user);
	String getName();
}
