package com.Hospital.View;

import com.Hospital.Model.Operations;
import com.Hospital.Model.User;

public class ViewReceipts implements Operations {

    public void operation(User user) {

    }

    public String getName() {
        return "View All Receipt";
    }
}
