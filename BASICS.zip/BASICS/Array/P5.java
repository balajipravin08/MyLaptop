import java.util.Scanner;
import java.util.Arrays;
class P5
{
public static void main(String[] args)
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a size of an array  : ");
int n = sc.nextInt();
int i=0;

String[] str = new String[n];


for(i=0;i<str.length();i++)
{
str[i]=sc.next();

}
//System.out.println(Arrays.toString(str));

for(i=0;i<str[i].length();i++)
{
System.out.println("b");
}


}
}
