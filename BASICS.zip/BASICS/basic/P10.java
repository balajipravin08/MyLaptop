import java.util.*;
public class P10{
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);

        //System.out.print("Enter the num1 : ");
        int num1= sc.nextInt();
         sc.nextLine();
        //System.out.print("Enter the num2 : ");
        int num2=sc.nextInt();

        int sum = num1+num2;
        System.out.print("the sum is : "+sum);


    }
}